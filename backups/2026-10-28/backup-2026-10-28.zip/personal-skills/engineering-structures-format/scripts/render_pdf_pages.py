"""Render every Word-exported PDF page with PDFium and record SHA-256 evidence."""
import argparse,hashlib,json
from pathlib import Path
import pypdfium2 as pdfium
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('pdf');p.add_argument('--out',required=True);p.add_argument('--scale',type=float,default=2);a=p.parse_args()
    src=Path(a.pdf);out=Path(a.out);out.mkdir(parents=True,exist_ok=True);doc=pdfium.PdfDocument(src);entries=[]
    for i,page in enumerate(doc):
        path=out/f'page-{i+1:02}.png';page.render(scale=a.scale).to_pil().save(path)
        entries.append({'page':i+1,'image':str(path.resolve()),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'visual_review':'PENDING'})
    manifest={'pdf':str(src.resolve()),'pdf_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'render_scale':a.scale,'pages':entries}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print(f'Rendered {len(entries)} pages; visual review required.')
