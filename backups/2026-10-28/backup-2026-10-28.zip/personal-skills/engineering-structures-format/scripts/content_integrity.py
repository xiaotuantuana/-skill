"""Exact content gate for formatting-only OOXML edits; exits nonzero on differences."""
import argparse, hashlib, json, re, zipfile
from copy import deepcopy
from pathlib import Path
from lxml import etree as E

NS = {'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
      'm':'http://schemas.openxmlformats.org/officeDocument/2006/math',
      'wp':'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
      'a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
def sha(data): return hashlib.sha256(data).hexdigest()
def semantic(root):
    r=deepcopy(root)
    # Formatting-only containers; all content, order, text, cell topology, objects remain.
    for x in list(r.iter()):
        if x.tag in [f"{{{NS['w']}}}{n}" for n in ['pPr','rPr','tblPr','tblPrEx','trPr','tblGrid']]:
            x.getparent().remove(x)
        elif x.tag==f"{{{NS['w']}}}tcPr":
            for y in list(x):
                if E.QName(y).localname not in ['gridSpan','vMerge']: x.remove(y)
        elif x.tag in [f"{{{NS['wp']}}}extent",f"{{{NS['a']}}}ext"]:
            for k in ['cx','cy']: x.attrib.pop(k,None)
        elif x.tag==f"{{{NS['w']}}}sectPr":
            for y in list(x):
                if E.QName(y).localname in ['cols','docGrid']: x.remove(y)
    return E.tostring(r,method='c14n')
def inventory(z):
    r=E.fromstring(z.read('word/document.xml')); ps=r.findall('.//w:p',NS)
    texts=[''.join(p.xpath('.//w:t/text()',namespaces=NS)) for p in ps]
    tabs=[[[ ''.join(c.xpath('.//w:t/text()',namespaces=NS)) for c in row.findall('w:tc',NS)] for row in t.findall('w:tr',NS)] for t in r.findall('.//w:tbl',NS)]
    caps=[s for s in texts if re.match(r'^(?:Fig\.|Table)\s*\d+\.',s)]
    eq=[s for s in texts if re.fullmatch(r'\s*\(\d+\)\s*',s)]
    body=r.find('w:body',NS); seq=[''.join(x.xpath('.//w:t/text()',namespaces=NS)) for x in body]
    ix=next((i for i,s in enumerate(seq) if s.strip()=='References'),None)
    refs=[s for s in seq[ix+1:] if s.strip()] if ix is not None else []
    return {'paragraph_texts':texts,'numeric_literals':[re.findall(r'(?<!\w)[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?',s) for s in texts],
            'table_cells':tabs,'captions':caps,'equation_numbers':eq,'references':refs,
            'omml':[E.tostring(x,method='c14n').decode() for x in r.findall('.//m:oMath',NS)],
            'fields':r.xpath('.//w:instrText/text()',namespaces=NS),
            'objects':[E.tostring(x,method='c14n').decode() for x in r.findall('.//w:object',NS)],
            'semantic_document_sha256':sha(semantic(r))}
def check(source,target):
    with zipfile.ZipFile(source) as a,zipfile.ZipFile(target) as b:
        ia,ib=inventory(a),inventory(b)
        checks={k:ia[k]==ib[k] for k in ia}
        checks['package_members']=a.namelist()==b.namelist()
        allowed={'word/document.xml','word/styles.xml'}
        checks['unchanged_other_parts']=all(n in b.namelist() and a.read(n)==b.read(n) for n in a.namelist() if n not in allowed)
        media=[n for n in a.namelist() if n.startswith(('word/media/','word/embeddings/'))]
        checks['media_and_embedded_objects']=all(a.read(n)==b.read(n) for n in media)
        labels=[re.match(r'Table\s*(\d+)',s).group(1) for s in ia['captions'] if s.startswith('Table')]
        return {'verdict':'PASS' if all(checks.values()) else 'FAIL','source':str(Path(source).resolve()),'target':str(Path(target).resolve()),
            'source_sha256':sha(Path(source).read_bytes()),'target_sha256':sha(Path(target).read_bytes()),'checks':checks,
            'counts':{'paragraphs':len(ia['paragraph_texts']),'native_tables':len(ia['table_cells']),'figure_captions':sum(s.startswith('Fig.') for s in ia['captions']),
                'display_equation_numbers':len(ia['equation_numbers']),'omml_objects':len(ia['omml']),'ole_objects':len(ia['objects']),'references':len(ia['references'])},
            'tables_1_to_4':{str(i):('EXACT_CELL_TEXT_AND_NUMBERS_PASS' if str(i) in labels and checks['table_cells'] else 'ABSENT_IN_SOURCE_NOT_APPLICABLE' if str(i) not in labels else 'FAIL') for i in range(1,5)}}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('target');p.add_argument('--out',required=True);a=p.parse_args()
    result=check(a.source,a.target);Path(a.out).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(0 if result['verdict']=='PASS' else 1)
