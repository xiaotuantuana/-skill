"""Structural formatting checks; visual checks remain mandatory."""
import argparse,json,re,zipfile
from pathlib import Path
from lxml import etree as E
from content_integrity import NS
W=NS['w'];q=lambda n:f'{{{W}}}{n}'
def audit(doc,plan):
    z=zipfile.ZipFile(doc);r=E.fromstring(z.read('word/document.xml'));styles=E.fromstring(z.read('word/styles.xml'));body=r.find('w:body',NS)
    result={'checks':{},'warnings':[],'tables':[]}
    checks=result['checks'];ps=body.findall('w:p',NS)
    checks['all_body_paragraphs_mapped']=len(ps)==plan['expected_paragraphs']
    checks['styles_present']=all(any(s.find(q('name')) is not None and s.find(q('name')).get(q('val')).lower()==name.lower() for s in styles.findall(q('style'))) for name in ['Title','Author information','Abstract','Keywords','heading 1','heading 2','heading 3','Normal','Figure Caption','Table Caption','References'])
    checks['single_column']=all(s.find(q('cols')).get(q('num'),'1')=='1' for s in r.findall('.//w:sectPr',NS))
    checks['body_12pt_double']=True
    for p in ps:
        st=p.find('w:pPr/w:pStyle',NS);sid=st.get(q('val')) if st is not None else 'a'
        if sid not in ['a','ESAbstract','ESAuthor','ESKeywords','ESReferences']:continue
        s=next(x for x in styles.findall(q('style')) if x.get(q('styleId'))==sid)
        checks['body_12pt_double'] &= s.find('w:rPr/w:sz',NS).get(q('val'))=='24' and s.find('w:pPr/w:spacing',NS).get(q('line'))=='480'
    checks['native_tables_inside_text_width']=True;checks['tables_white_no_verticals']=True;checks['rows_not_split']=True;checks['mapped_headers_repeat']=True
    for t,mp in zip(r.findall('.//w:tbl',NS),plan['tables']):
        widths=[int(x.get(q('w'))) for x in t.findall('w:tblGrid/w:gridCol',NS)]
        checks['native_tables_inside_text_width'] &= sum(widths)<=plan['text_width_twips']
        for x in t.findall('.//w:shd',NS): checks['tables_white_no_verticals'] &= x.get(q('fill'),'auto') in ['auto','FFFFFF']
        for container in t.xpath('.//w:tblBorders | .//w:tcBorders',namespaces=NS):
            for n in ['left','right','start','end','insideV']:
                x=container.find(q(n));checks['tables_white_no_verticals'] &= x is None or x.get(q('val')) in ['none','nil']
        for i,row in enumerate(t.findall(q('tr'))):
            checks['rows_not_split'] &= row.find('w:trPr/w:cantSplit',NS) is not None
            if i in mp['repeat_headers']:checks['mapped_headers_repeat'] &= row.find('w:trPr/w:tblHeader',NS) is not None
        prev=t.getprevious();text=''.join(prev.xpath('.//w:t/text()',namespaces=NS)) if prev is not None else ''
        result['tables'].append({'label':mp['label'],'caption_above':text.startswith(mp['label']+'.'),'width_twips':sum(widths),'header_rule_rows':mp['header_rules']})
    checks['table_captions_above']=all(x['caption_above'] for x in result['tables'])
    texts=[''.join(p.xpath('.//w:t/text()',namespaces=NS)) for p in ps]
    labels=[int(re.match(r'Table\s+(\d+)\.',t).group(1)) for t in texts if re.match(r'Table\s+\d+\.',t)]
    if labels!=list(range(1,len(labels)+1)):result['warnings'].append('Existing table numbering is not consecutive: '+str(labels)+'. Preserved; no FORMAT-ONLY renumbering.')
    bodytext=' '.join(t for t in texts if not re.match(r'^(?:Table\s+\d+\.|Fig\.\s*\d+\.)',t))
    result['table_citation_numbers']=sorted(set(map(int,re.findall(r'\bTable\s+(\d+)',bodytext))))
    if set(result['table_citation_numbers'])-set(labels):result['warnings'].append('Body cites a table absent from the source.')
    result['verdict']='PASS' if all(checks.values()) else 'FAIL'
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('docx');p.add_argument('--plan',required=True);p.add_argument('--out',required=True);a=p.parse_args();r=audit(a.docx,json.loads(Path(a.plan).read_text(encoding='utf-8')));Path(a.out).write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r,indent=2));raise SystemExit(0 if r['verdict']=='PASS' else 1)
