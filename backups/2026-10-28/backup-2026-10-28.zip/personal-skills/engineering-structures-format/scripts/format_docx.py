"""Plan-driven, content-preserving formatter. Never assigns text or rewrites objects."""
import argparse,json,zipfile,hashlib,re
from pathlib import Path
from lxml import etree as E
from content_integrity import check,NS

W=NS['w']; q=lambda n:f'{{{W}}}{n}'
def child(x,n):
    y=x.find(q(n))
    if y is None: y=E.SubElement(x,q(n))
    return y
def put(x,n,**attrs):
    y=child(x,n);y.attrib.clear()
    for k,v in attrs.items(): y.set(q(k),str(v))
    return y
def remove(x,*names):
    for n in names:
        for y in list(x.findall(q(n))): x.remove(y)
def fonts(r,size=24,bold=None):
    put(r,'rFonts',ascii='Times New Roman',hAnsi='Times New Roman',eastAsia='Times New Roman',cs='Times New Roman')
    put(r,'sz',val=size);put(r,'szCs',val=size);put(r,'color',val='000000')
    remove(r,'highlight','shd','u','strike','dstrike','spacing','w','position')
    if bold is not None: put(r,'b',val=int(bold));put(r,'bCs',val=int(bold))
def style(root,id,name,*,align='left',size=24,bold=False,before=0,after=0,keep=False,outline=None,italic=False):
    s=next((x for x in root.findall(q('style')) if x.get(q('styleId'))==id),None)
    if s is None: s=E.SubElement(root,q('style'),{q('type'):'paragraph',q('styleId'):id})
    put(s,'name',val=name)
    if id!='a': put(s,'basedOn',val='a')
    put(s,'next',val='a'); child(s,'qFormat')
    for n in ['pPr','rPr']: remove(s,n)
    p=child(s,'pPr');put(p,'jc',val=align);put(p,'spacing',before=before,after=after,line=480,lineRule='auto');put(p,'ind',left=0,right=0,firstLine=0)
    put(p,'keepNext',val=int(keep));put(p,'keepLines',val=int(keep));put(p,'widowControl',val=1);put(p,'snapToGrid',val=0)
    if outline is not None: put(p,'outlineLvl',val=outline)
    r=child(s,'rPr');fonts(r,size,bold);put(r,'i',val=int(italic))
def apply_para(p,sid):
    pr=child(p,'pPr')
    remove(pr,'spacing','ind','jc','keepNext','keepLines','pageBreakBefore','contextualSpacing','pBdr','shd','tabs','snapToGrid')
    put(pr,'pStyle',val=sid)
    # Preserve numbering, section breaks, all text and mathematical runs.
    for r in p.findall('.//w:r',NS):
        if any(E.QName(a).namespace==NS['m'] for a in r.iterancestors()): continue
        rp=child(r,'rPr')
        remove(rp,'rStyle','rFonts','sz','szCs','color','highlight','shd','u','strike','dstrike','spacing','w','position')
        if sid in ['a3','1','2','3','ESTableHeader','ESTableBody','ESAuthor','ESAbstract','ESKeywords','ESFigureCaption','ESTableCaption','ESReferences']:
            # Retain semantic italics and super/subscripts; headings/headers get style bold.
            remove(rp,'b','bCs')
        if sid in ['a3','1','2','3']: remove(rp,'i','iCs')
def border(parent,n,size=None):
    return put(parent,n,val='none') if size is None else put(parent,n,val='single',sz=size,space=0,color='000000')
def format_file(source,target,plan,changes):
    source,target=Path(source),Path(target)
    if source.resolve()==target.resolve() or target.exists(): raise ValueError('New output path required; refusing overwrite')
    if hashlib.sha256(source.read_bytes()).hexdigest()!=plan['source_sha256']: raise ValueError('Source differs from reviewed plan')
    with zipfile.ZipFile(source) as z:
        root=E.fromstring(z.read('word/document.xml'));styles=E.fromstring(z.read('word/styles.xml'))
        style(styles,'a','Normal')
        style(styles,'a3','Title',align='center',size=28,bold=True,after=120,keep=True)
        for i in range(1,4): style(styles,str(i),f'heading {i}',bold=True,before=180,after=60,keep=True,outline=i-1,italic=i==3)
        for sid,name in [('ESAuthor','Author information'),('ESAbstract','Abstract'),('ESKeywords','Keywords'),('ESReferences','References')]: style(styles,sid,name)
        style(styles,'ESFigureCaption','Figure Caption',after=120)
        style(styles,'ESTableCaption','Table Caption',before=120,after=60,keep=True)
        style(styles,'ESFigure','Figure',align='center',keep=True)
        style(styles,'ESEquation','Equation')
        style(styles,'ESTableBody','Table Body',size=22)
        style(styles,'ESTableHeader','Table Header',size=22,bold=True)
        defaults=child(styles,'docDefaults');fonts(child(child(defaults,'rPrDefault'),'rPr'))
        dp=child(child(defaults,'pPrDefault'),'pPr');put(dp,'spacing',before=0,after=0,line=480,lineRule='auto');put(dp,'snapToGrid',val=0)
        body=root.find('w:body',NS);paras=body.findall('w:p',NS)
        if plan.get('expected_paragraphs')!=len(paras): raise ValueError('Source structure does not match reviewed plan')
        for i,p in enumerate(paras):
            sid=plan['paragraph_styles'].get(str(i),'a'); apply_para(p,sid)
            if sid=='ESEquation':
                pr=child(p,'pPr');tabs=child(pr,'tabs');put(pr,'jc',val='left')
                E.SubElement(tabs,q('tab'),{q('val'):'center',q('pos'):str(plan['text_width_twips']//2)})
                E.SubElement(tabs,q('tab'),{q('val'):'right',q('pos'):str(plan['text_width_twips'])})
            if str(i) in plan.get('keep_next',[]): put(child(p,'pPr'),'keepNext',val=1)
            if str(i) in plan.get('page_break_before',[]): put(child(p,'pPr'),'pageBreakBefore',val=1)
            if str(i) in plan.get('spacing_before',{}): put(child(p,'pPr'),'spacing',before=plan['spacing_before'][str(i)],after=0,line=480,lineRule='auto')
            if str(i) in plan.get('equation_number_raise',{}):
                for run in p.findall('w:r',NS):
                    if re.fullmatch(r'\s*\(\d+\)\s*',''.join(run.xpath('.//w:t/text()',namespaces=NS))):
                        put(child(run,'rPr'),'position',val=plan['equation_number_raise'][str(i)])
        for sec in root.findall('.//w:sectPr',NS):
            put(sec,'cols',num=1,space=425);remove(sec,'docGrid')
        # Preserve image bytes; scale drawing dimensions only if overfull.
        for p in paras:
            ex=p.findall('.//wp:extent',NS)
            if not ex: continue
            total=sum(int(x.get('cx')) for x in ex);maxw=plan['text_width_twips']*635
            factor=min(1,maxw/max(total,1))
            if factor<1:
                for x in ex:
                    draw=next(a for a in x.iterancestors() if a.tag==q('drawing'))
                    for y in draw.xpath('.//wp:extent | .//a:xfrm/a:ext',namespaces=NS):
                        for k in ['cx','cy']:
                            if y.get(k): y.set(k,str(round(int(y.get(k))*factor)))
        tables=root.findall('.//w:tbl',NS)
        if len(tables)!=len(plan['tables']): raise ValueError('Table mapping mismatch')
        for table,mp in zip(tables,plan['tables']):
            pr=child(table,'tblPr');remove(pr,'tblStyle','tblBorders','shd','tblLook','tblCellMar')
            put(pr,'tblStyle',val='TableNormal');put(pr,'tblLook',val='0000',firstRow=0,lastRow=0,firstColumn=0,lastColumn=0,noHBand=1,noVBand=1)
            put(pr,'tblW',w=sum(mp['widths']),type='dxa');put(pr,'jc',val='center');put(pr,'tblLayout',type='fixed');put(pr,'tblInd',w=0,type='dxa')
            margins=child(pr,'tblCellMar')
            for n,v in [('top',40),('bottom',40),('left',30),('right',30)]:put(margins,n,w=v,type='dxa')
            bs=child(pr,'tblBorders')
            for n in ['left','right','start','end','insideH','insideV']:border(bs,n)
            border(bs,'top',12);border(bs,'bottom',12)
            grid=child(table,'tblGrid');grid.clear()
            for width in mp['widths']: E.SubElement(grid,q('gridCol'),{q('w'):str(width)})
            for ri,row in enumerate(table.findall('w:tr',NS)):
                rp=child(row,'trPr');remove(rp,'trHeight','tblHeader');put(rp,'cantSplit',val=1)
                if ri in mp['repeat_headers']:put(rp,'tblHeader',val=1)
                for ex in row.findall('w:tblPrEx',NS):remove(ex,'tblBorders','shd','tblStyle','tblLook')
                col=0
                for cell in row.findall('w:tc',NS):
                    cp=child(cell,'tcPr');span=cp.find(q('gridSpan'));span=int(span.get(q('val'))) if span is not None else 1
                    put(cp,'tcW',w=sum(mp['widths'][col:col+span]),type='dxa');remove(cp,'tcBorders','shd','noWrap','tcMar');put(cp,'vAlign',val='center')
                    bs=child(cp,'tcBorders')
                    for n in ['left','right','start','end','insideH','insideV','top','bottom']:border(bs,n)
                    if ri==0:border(bs,'top',12)
                    if ri in mp['header_rules']:border(bs,'bottom',6)
                    if ri==len(table.findall('w:tr',NS))-1:border(bs,'bottom',12)
                    for p in cell.findall('.//w:p',NS):
                        apply_para(p,'ESTableHeader' if ri in mp['bold_rows'] else 'ESTableBody')
                        put(child(p,'pPr'),'jc',val='left' if col==0 else 'center')
                        put(child(p,'pPr'),'keepNext',val=int(mp.get('keep_table',False)))
                    col+=span
        data={'word/document.xml':E.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True),
              'word/styles.xml':E.tostring(styles,xml_declaration=True,encoding='UTF-8',standalone=True)}
        target.parent.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(target,'w') as out:
            for item in z.infolist():out.writestr(item,data.get(item.filename,z.read(item.filename)))
    result=check(source,target)
    Path(str(target)+'.integrity.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    if result['verdict']!='PASS':raise RuntimeError('Content gate failed; output is not deliverable')
    Path(changes).write_text('# FORMAT CHANGES\n\n'+ '\n'.join('- '+s for s in plan['change_log'])+'\n',encoding='utf-8')
    print('Content integrity PASS; new formatted file:',target)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('target');p.add_argument('--plan',required=True);p.add_argument('--changes',required=True);a=p.parse_args()
    format_file(a.source,a.target,json.loads(Path(a.plan).read_text(encoding='utf-8')),a.changes)
