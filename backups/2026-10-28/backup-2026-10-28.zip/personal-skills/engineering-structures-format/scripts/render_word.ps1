param([Parameter(Mandatory=$true)][string]$Source,[Parameter(Mandatory=$true)][string]$Pdf,[Parameter(Mandatory=$true)][string]$LayoutJson)
$ErrorActionPreference='Stop'
$taskWord=$null; $taskDoc=$null
try {
    $taskWord=New-Object -ComObject Word.Application
    $taskWord.Visible=$false; $taskWord.DisplayAlerts=0; $taskWord.AutomationSecurity=3
    $taskWord.Options.UpdateLinksAtOpen=$false
    $taskWord.Options.UpdateFieldsAtPrint=$false
    $taskWord.Options.UpdateLinksAtPrint=$false
    $taskDoc=$taskWord.Documents.Open($Source,$false,$true,$false)
    $taskDoc.Repaginate()
    $taskPages=$taskDoc.ComputeStatistics(2)
    $taskObjects=@()
    foreach($taskParagraph in $taskDoc.Paragraphs){
        $taskText=$taskParagraph.Range.Text.Trim()
        if($taskText -match '^(Fig\.\s*\d+\.|Table\s*\d+\.|References$|\(\d+\)$)' -or $taskParagraph.Range.InlineShapes.Count -gt 0){
            $taskObjects+=@{text=$taskText;page=$taskParagraph.Range.Information(3);endPage=$taskParagraph.Range.Characters.Last.Information(3);inlineShapes=$taskParagraph.Range.InlineShapes.Count}
        }
    }
    $taskTables=@()
    foreach($taskTable in $taskDoc.Tables){$taskTables+=@{page=$taskTable.Range.Information(3);endPage=$taskTable.Range.Characters.Last.Information(3);rows=$taskTable.Rows.Count}}
    $taskDoc.ExportAsFixedFormat($Pdf,17)
    @{renderer='Microsoft Word';version=$taskWord.Version;pages=$taskPages;objects=$taskObjects;tables=$taskTables}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $LayoutJson -Encoding utf8
    Write-Output ('Word export complete: '+$taskPages+' pages')
} finally {
    if($null -ne $taskDoc){$taskDoc.Close(0)}
    if($null -ne $taskWord){$taskWord.Quit()}
}
