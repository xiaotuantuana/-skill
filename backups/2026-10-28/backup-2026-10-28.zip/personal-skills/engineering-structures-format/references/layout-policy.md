# Layout policy and tool provenance

Verified on 2026-10-02 against user requirements and source structure. Recheck official guidance on future runs.

## Sources

1. Engineering Structures: https://www.sciencedirect.com/journal/engineering-structures/publish/guide-for-authors . Official access returned 403 during this run. A reported 30-page research-paper / 40-page review limit (everything except references) remains provisional until direct official verification. User explicitly requires single column, 12 pt body and double spacing.
2. Elsevier submission guidance: https://www.elsevier.support/publishing/answer/how-do-i-prepare-my-files-for-submission-in-editorial-manager . Journal requirements override general advice; editable/simple manuscript layout.
3. General manuscript preparation: https://www.elsevier.com/publishing/publish-in-a-journal/manuscript-preparation . Consult target journal first.
4. Confirmed source structure and conventional English manuscript layout. Times New Roman, black headings and left-aligned text are local formatting choices, not claimed journal-mandated fonts. Preserve original A4 / 20 mm margins when confirmed; no artificial pagination compression.

## Supporting skills inspected and installed

| Repository | Pinned commit | Scope |
|---|---|---|
| GuangyaoYin/skill-paper2pdf | d6f0626c3670753effd6f9886659092356d36713 | Official guideline priority, layout planning, visual QA. Ignore its environment-specific WSL assumption and LaTeX reconstruction route for existing Word equations. |
| wksudud/format-thesis-docx | c04f786d5b994879f938325630e9ffdf4dde00be | Full DOCX-part checklist, audit-before-copy-edit, evidence and unresolved findings. No thesis template is required when official journal/user rules provide authority. Do not use broad template application that could lose original objects. |
| AllenWang2005/Word-typesetting | aac8f06353beb2d5f7b78645b4a73e2f1a73c47d | Reuse three-line-table OOXML implementation: eighth-point rule sizes, remove table-style inheritance, clear shading/row exceptions. No Chinese defaults, GB/T 7714, chapter renumbering, citation transformation, formula conversion, punctuation/unit rewriting or finalize/normalize command. |

The local formatter adapts the three-line-table recipe and the full-part audit checklist; it does not execute the upstream content-mutating scripts. Installed upstream Skills keep their original instructions: when used here, this policy and the user's FORMAT-ONLY instructions override incompatible defaults.

## Concrete styles

Body, abstract, authors, keywords, captions, references and headings use 12 pt Times New Roman and double spacing. Title 14 pt bold. Heading levels 1/2 bold and level 3 bold italic. Body left aligned, no automatic hyphenation, paragraph spacing 0 before/after; headings/captions use modest whitespace and keep-with-next where appropriate. References keep original numbering and content; hanging indentation is formatting only.

Table Header/Body: 11 pt Times New Roman, double spacing, white background; bold header, text labels left and numeric cells consistently centered. Never shrink below 10.5 pt automatically. Top/bottom 1.5 pt and header rule 0.75 pt are chosen journal-style defaults, not official mandatory dimensions. Use explicit widths fitting the original text area and small consistent cell margins. Compound tables need inspected header mappings and may require one thin rule under each subgroup header; no arbitrary row grid.

Figures use inline centered layout where already inline. Never modify their image bytes or crop. Constrain existing dimensions proportionally only when overflowing. Multi-image rows retain order and relative scaling; aggregate widths must fit. Center subfigure-label paragraphs without editing their text; pre-existing manual-space alignment may need a documented formatting-only tab/column arrangement if it remains visually defective.

Equations: preserve both OMML and OLE (e.g. Equation Editor/MathType); no field update or conversion. Use existing tabs/content positions, suitable center/right tab stops, and verify every number in Word PDF. Keep paragraphs rather than introducing content-changing layout tables.
