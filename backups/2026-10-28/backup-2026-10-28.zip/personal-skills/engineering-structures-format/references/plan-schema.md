# Reviewed plan input

Create this plan only from a structural audit of the actual DOCX. `paragraph_styles` indexes direct `w:body/w:p` paragraphs, zero based; table paragraphs are separate. Style IDs include `a` Normal, `a3` Title, `1`/`2`/`3` headings and `ESAuthor`, `ESAbstract`, `ESKeywords`, `ESReferences`, `ESFigureCaption`, `ESTableCaption`, `ESFigure`, `ESEquation`.

Required JSON fields:

- `source_sha256`: reviewed source byte hash; mismatches abort.
- `expected_paragraphs`: direct body paragraph count; mismatches abort.
- `text_width_twips`: confirmed page width minus existing left/right margins. Do not reduce margins.
- `paragraph_styles`: object with string indices and style IDs; unmapped paragraphs become Normal. Inspect all mappings before running.
- `tables`: one entry per native table, in source order. Each has `label`, `widths` (grid-column widths in twips), `repeat_headers` (leading contiguous row indices only), `header_rules` (row indices with a bottom header rule), `bold_rows` and optional `keep_table`. Compound subgroup header rows should be inspected individually. Keep entire table only if it fits a page; otherwise allow row-level flow and genuine repeat headers.
- `change_log`: only actual formatting changes.

Optional: `keep_next` and `page_break_before` arrays of string paragraph indices; `spacing_before` maps indices to twips; `equation_number_raise` maps indices to half-point baseline shifts for existing number runs. Do not reuse a prior manuscript's indices or shifts without visual evidence.

The formatter does not reorder captions, convert floating pictures or redesign merged cells automatically. These require inspected, bounded OOXML formatting changes and another content gate. Do not claim these repairs occurred merely because a style was applied.

Run using the Python/Node paths returned by Codex `load_workspace_dependencies`. On Windows, render via `render_word.ps1 -Source NEW_DOCX -Pdf PDF -LayoutJson LAYOUT.json`, then `render_pdf_pages.py PDF --out QA_PAGES`. Inspect every image. `manifest.json` records PENDING until an actual visual review completes; update individual reviews only after inspection and bind the record to the final PDF hash.
