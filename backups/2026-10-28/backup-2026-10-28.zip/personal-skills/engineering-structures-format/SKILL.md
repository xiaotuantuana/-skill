---
name: engineering-structures-format
description: Format and visually verify English Engineering Structures manuscript DOCX files before submission without changing research content, equations, citations, captions, or numbering. Produces a new editable DOCX, Word-rendered PDF, formatting audit, and content-integrity evidence.
---

# Engineering Structures format-only workflow

The sole goal is submission manuscript layout and final Word visual inspection. FORMAT-ONLY is mandatory, including manuscripts already language-polished. Preserve the source; never overwrite it.

## Authority

Read the current [Engineering Structures Guide for Authors](https://www.sciencedirect.com/journal/engineering-structures/publish/guide-for-authors) first, then current Elsevier general author guidance, confirmed source structure, and conventional English engineering layout. Record access date, URL, evidence and access failures. Never represent a blocked official page or a third-party copy as current official verification. Read [references/layout-policy.md](references/layout-policy.md) for the layout and integration decisions.

## Protection and intake

- Record source absolute path and SHA-256. Audit all DOCX parts, sections, styles, native tables, figures, OLE/OMML equations, captions, fields, headers/footers, notes, references and revision markup before editing.
- Do not rewrite sentences, experiment numbers, table cells, formula content, citations, conclusions or caption semantics. Do not delete paragraphs, accept/reject tracked changes, add conclusions, polish language, or renumber any object. Preserve intentional scientific italics, superscripts and subscripts.
- Missing captions, missing tables, inconsistent references and numbering are audit findings; formatting permission does not authorize repairing them. Never invent Tables 2/4 to satisfy a checklist.
- Preserve image and embedded-equation bytes, aspect ratios, document content order, lists and reference content. Do not recreate the manuscript from extracted text or convert tables/equations to images.

## Execute

1. Audit and map actual paragraphs/tables to styles and header rows. Do not infer positions for another manuscript from a previous source. Create a JSON layout plan for the helper only after inspection; read [references/plan-schema.md](references/plan-schema.md) for inputs and runtime usage.
2. Use `scripts/format_docx.py SOURCE NEW_DOCX --plan PLAN --changes FORMAT_CHANGES.md` for conservative OOXML changes. It refuses overwriting and preserves nonedited ZIP members. Run `scripts/audit_layout.py NEW_DOCX --plan PLAN --out AUDIT.json` for structural checks. Its automatic integrity check must pass; use `scripts/content_integrity.py SOURCE NEW_DOCX --out REPORT.json` again after the last modification.
3. Keep single-column, 12 pt body and double line spacing. Preserve confirmed page size/margins/section organization; do not compress page count. Build Title, Author information, Abstract, Keywords, Heading 1/2/3, Normal, Figure Caption, Table Caption and References styles. Table Body/Header, Figure and Equation styles can support these.
4. Normalize native tables to white three-line layout, with top/header-bottom/bottom rules, no verticals or unnecessary body rules. Set sensible widths, repeat identified header rows, prevent row splitting. Keep numeric literals exact. Never abbreviate headings or move units by rewriting text. A compound table can retain subgroup heading rules where required for legibility; disclose the exception.
5. Center images, constrain to text area by proportional downscaling only, pair figures with captions below; pair table captions above, notes below. Keep equations editable in their existing OMML/OLE form and preserve numbers. Format equation paragraph alignment/tabs only after inspecting the existing number mechanism.
6. Render with Microsoft Word where available via `scripts/render_word.ps1`; opens read-only, disables link/field updates, exports without saving. Otherwise use the documents skill bundled renderer; name the renderer and never claim Word verification from another engine.
7. Use `scripts/render_pdf_pages.py PDF --out QA_PAGES` to render every PDF page to images. Inspect every page individually at readable resolution, especially every table, figure, equation, section transition, references and last page. Fix only layout and rerender; inspect latest output. Record page-by-page verdicts and page-count method. Count everything except references for the research-paper limit; verify current official limit before claiming journal compliance. Do not change margins/spacing/font to pass the limit.
8. Recheck content integrity and source hash. PASS requires exact paragraph text, every numeric literal, table cells, captions/numbering, references, semantic XML, OMML, fields, media and OLE preservation. Inventory missing Tables 1–4 separately; absent tables are NOT_APPLICABLE, never an equality PASS for nonexistent values.

## Deliver

Deliver only when the final content-integrity check and visual review pass:

- Manuscript_ES_format_final.docx
- Manuscript_ES_format_final.pdf only when PDF delivery is requested. Respect requests not to export or deliver PDF; any earlier rendering remains internal QA, and no additional exports follow that request.
- ENGINEERING_STRUCTURES_FORMAT_AUDIT.md
- FORMAT_CHANGES.md

Formatting audit must distinguish layout PASS, content integrity PASS, existing content/numbering issues and unverified current journal rules. FORMAT_CHANGES lists only actual formatting changes. Preserve run manifest, plan, source hash, integrity JSON and page-review evidence for reproducibility. Installed supporting skills become available on the user's next turn.
