---
name: academic-manuscript-style-guard
description: Review and revise academic manuscript language, remove defensive reviewer-response prose, and audit journal style while preserving scientific accuracy and reproducibility. Use for manuscript polishing, methods, results, discussion, abstracts, conclusions, and captions.
---

# Academic Manuscript Style Guard

Before performing any manuscript review or revision with this skill, read [the complete original instructions](references/SKILL.md) in full and apply all of them. That file is the user-provided, unmodified skill. Do not substitute this entry point for its rules or simplify them.