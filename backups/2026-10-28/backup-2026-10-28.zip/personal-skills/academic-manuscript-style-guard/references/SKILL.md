# Academic Manuscript Style Guard

## Purpose

Review and revise academic manuscripts so that the main text reads like a standard journal article rather than a response-to-reviewers document.

The skill is designed for engineering and scientific manuscripts, especially methods, experiments, results, discussion, figure captions, abstracts, and conclusions.

## Core writing principle

Main-text prose should primarily state:

- what was done;
- how it was done;
- what parameters or data were used;
- what was observed;
- what the result indicates;
- how the result connects to the method or engineering application.

Avoid repeatedly explaining what was **not** done, what the study **cannot** prove, what a result **should not** be interpreted as, or what a parameter **is not**.

Necessary limitations belong mainly in the Discussion or Future Work section and should be concise, consolidated, and written constructively.

## When to use this skill

Use this skill when the user asks to:

- polish an academic paper;
- review manuscript language;
- remove defensive/reviewer-response wording;
- make a paper read more like a normal journal article;
- perform a final language-style audit;
- rewrite methods, results, discussion, abstract, conclusion, or figure captions;
- check whether revision comments have leaked into the manuscript body.

## Primary rule

Do not mechanically delete every negative word.

First determine whether a sentence is:

1. **scientifically necessary** — keep or lightly polish it;
2. **a definition or scope boundary** — keep if needed for reproducibility;
3. **reviewer-response style / defensive explanation** — rewrite or remove;
4. **a limitation** — move or consolidate into Discussion/Future Work when possible.

## Reviewer-response style to remove or rewrite

Flag sentences whose primary function is to defend, disclaim, or explain omissions rather than advance the manuscript.

Common patterns include:

- does not...
- do not...
- cannot...
- is not...
- are not...
- rather than...
- does not claim...
- does not establish...
- should not be interpreted as...
- not intended to...
- not independently...
- no additional...
- no statistical...
- no normal...
- these settings belong to... not to...
- their values are not interchangeable
- not a controlled experiment...
- within the tested scope
- under the tested conditions
- under the tested acquisition conditions
- known missing-member counts
- case-specific thresholds
- manually verified / visually confirmed, when repeated defensively throughout the manuscript

These phrases are not automatically wrong. Judge them by function and context.

## Preferred rewrite logic

### Method section

Prefer:

> X is used to...
> X controls...
> X provides...
> X is evaluated using...
> The point cloud is aligned...
> The parameter is set to...
> The resulting geometry is used for...

Avoid:

> X does not...
> X is not...
> X should not be interpreted as...
> These parameters do not represent...

### Results section

Prefer:

> The method reduced...
> The configuration achieved...
> The analysis showed...
> The result indicates...
> Feature matching contributed substantially to...
> Registration remained stable across the evaluated range.

Avoid:

> This result does not prove...
> The acceleration does not refer to...
> The result should not be interpreted as...
> This was not designed to...

### Figure captions

Captions should describe what is shown.

Prefer:

> Yellow regions indicate localized geometric discrepancies corresponding to missing-member positions.

Avoid:

> Yellow regions indicate visually confirmed locations selected using case-specific thresholds based on known missing-member counts.

Keep implementation caveats in Methods or Discussion only when scientifically necessary.

### Discussion / limitations

Limitations are allowed, but consolidate them.

Prefer constructive future-work language:

> Future studies will extend validation to larger defect numbers and broader acquisition conditions. Calibrated experiments will quantify physical detection resolution and minimum detectable member dimensions.

Avoid repeatedly writing:

> The present study does not...
> We cannot...
> This does not establish...
> The current results should not be interpreted as...

## Scientific accuracy safeguard

Never improve style by overstating evidence.

Do not convert:

> member-level visual verification

into:

> independent automatic ground-truth validation

unless the source data actually support that statement.

Do not convert:

> visualization / localization

into:

> fully automatic detection

unless the manuscript and evidence support a fully automatic process.

Do not hide material facts that are necessary for reproducibility or for interpreting a quantitative result.

## Necessary negative statements that may remain

Keep negative or exclusionary wording when it serves a genuine technical purpose, for example:

- defining the timing boundary of a benchmark:
  > Total time covers feature extraction, matching, sparse mapping, training, and point-cloud export, excluding metric evaluation and subsequent registration and detection.

- disambiguating symbols:
  > T denotes a rigid mapping distinct from ray transmittance T(t).

- stating a scientifically essential limitation once in Discussion:
  > Physical detection resolution remains to be calibrated.

- describing an actual experimental absence that materially changes interpretation.

The rule is not “ban negative grammar”; the rule is “ban defensive reviewer-response prose from the main narrative.”

## Section-by-section review checklist

### Abstract
- Focus on problem, method, validation, principal quantitative results, conclusion.
- Avoid defensive scope qualifiers unless essential.
- Do not repeat limitations.

### Introduction
- End with method concept, contributions, and validation design.
- Avoid reviewer-response sentences about what is not novel or what is not evaluated.
- Established methods can be identified neutrally.

### Methods
- Keep the technical chain complete.
- Preserve equations, symbols, parameter definitions, and reproducibility details.
- Describe parameter roles positively.
- Avoid explaining every possible misinterpretation.

### Experiments / Results
- Report measured values directly.
- Highlight important improvements and findings.
- Do not hide adverse results that are essential to interpretation.
- Avoid repeated qualification of every result.

### Discussion
- Interpret engineering meaning.
- Consolidate limitations into one compact paragraph.
- Prefer future-work framing where appropriate.

### Conclusion
- State the main findings directly.
- Avoid phrases such as “within the tested scope” unless absolutely necessary.
- Do not repeat the full limitations paragraph.

### Figures / Tables
- Captions describe content and variables.
- Do not turn captions into mini response letters.
- Keep table notes limited to definitions, units, datasets, or necessary methodological context.

## Editing constraints

Unless the user explicitly asks for a structural rewrite:

- do not change numerical values;
- do not invent data;
- do not remove equations;
- do not alter formula numbering;
- do not change figure/table numbering;
- do not change references;
- do not modify established technical meaning;
- do not expand the manuscript unnecessarily;
- do not add unsupported claims;
- preserve journal-style academic English.

## Audit procedure

When reviewing a manuscript:

1. Scan the full manuscript for reviewer-response / defensive wording.
2. Inspect each match in context.
3. Classify it as:
   - KEEP — technically necessary;
   - REWRITE — same fact, better journal prose;
   - MOVE — belongs in Discussion/Future Work;
   - DELETE — redundant reviewer-response language.
4. Check Abstract, Introduction ending, Methods ending, figure captions, Results, Discussion, and Conclusion manually even if keyword search finds nothing.
5. Verify that rewrites do not overclaim.
6. Perform a second pass for repeated qualifiers such as:
   - tested
   - verified
   - visually confirmed
   - case-specific
   - scope
   - limitation
   - cannot
   - does not
   - rather than
7. Return only necessary changes.

## Preferred output format

For a manuscript audit, report:

### Overall status
PASS / PASS WITH MINOR FIXES / NEEDS REVISION

### Required changes
For each issue:
- location;
- original sentence;
- revised sentence;
- reason in one short line.

### Keep unchanged
List any suspicious-looking negative statements that should remain because they define:
- reproducibility;
- benchmark boundaries;
- symbol meanings;
- essential limitations.

## Final standard

The final manuscript should read as if it was written as a coherent journal article from the beginning, not as if reviewer comments were answered sentence by sentence.

The main narrative should follow:

**method → implementation → result → interpretation → engineering relevance**

not:

**claim → disclaimer → exception → reviewer clarification → limitation**
