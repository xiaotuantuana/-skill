# Roadmap

## Near Term

- [x] Reproducible smoke test with generated sample DOCX files.
- [x] Static live demo on GitHub Pages.
- [ ] Web upload flow for template and paper.
- [ ] CI workflow that runs `tests/smoke_test.py` on every push.
- [ ] Add a visual before/after diff view.

## Product

- [ ] More automatic repair rules: table width, captions, numbering, page breaks, and running headers.
- [ ] English/Chinese sample templates for common university formats.
- [ ] A packaged CLI with `format-thesis <template> <paper> --out`.
- [ ] A local web app that keeps all processing on the user's machine.

## Community

- [ ] Contribution guide.
- [ ] Community-contributed template requirement packs.
- [ ] Benchmark report showing how many common requirements can be auto-detected and auto-fixed.

## Non-Goals

- Rewriting academic content.
- Translating papers or changing citation meaning.
- Handling DRM-protected, password-protected, or non-DOCX documents.
- Uploading user files to a cloud service.
