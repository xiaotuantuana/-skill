#!/usr/bin/env python3
"""Run the full format-thesis-docx pipeline against synthetic sample files."""

from __future__ import annotations

import csv
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
EXAMPLES = ROOT / "examples"


def run_python(script: Path, *args: str) -> None:
    subprocess.run(
        [sys.executable, str(script), *args],
        cwd=str(ROOT),
        check=True,
        capture_output=True,
        text=True,
    )


def read_zip_text(path: Path, member: str) -> str:
    with zipfile.ZipFile(path) as zf:
        return zf.read(member).decode("utf-8")


def main() -> int:
    sys.path.insert(0, str(SCRIPTS))
    from make_sample_docx import make_samples

    template, paper = make_samples(ROOT)
    work = Path(tempfile.mkdtemp(prefix="format-thesis-smoke-"))
    try:
        req_dir = work / "requirements"
        audit_dir = work / "audit"
        fix_dir = work / "fixed"

        run_python(SCRIPTS / "extract_requirements.py", "--template", str(template), "--out", str(req_dir))
        run_python(
            SCRIPTS / "audit_format.py",
            "--requirements",
            str(req_dir / "requirements.json"),
            "--paper",
            str(paper),
            "--out",
            str(audit_dir),
        )
        run_python(
            SCRIPTS / "apply_format.py",
            "--requirements",
            str(req_dir / "requirements.json"),
            "--audit",
            str(audit_dir / "format_audit.csv"),
            "--paper",
            str(paper),
            "--out",
            str(fix_dir),
        )

        requirements = json.loads((req_dir / "requirements.json").read_text(encoding="utf-8"))
        assert len(requirements["requirements"]) >= 6, "expected multiple extracted requirements"

        audit_rows = list(csv.DictReader((audit_dir / "format_audit.csv").open(encoding="utf-8-sig")))
        assert audit_rows, "audit csv should not be empty"
        assert any(row["status"] == "fail" for row in audit_rows), "sample paper should contain failures"

        changes = list(csv.DictReader((fix_dir / "changes.csv").open(encoding="utf-8-sig")))
        assert changes, "changes csv should not be empty"
        assert any(row["status"] in {"changed", "already-set"} for row in changes), "expected at least one applied fix"

        formatted = fix_dir / f"{paper.stem}_formatted.docx"
        assert formatted.exists(), "formatted docx should be created"
        styles_xml = read_zip_text(formatted, "word/styles.xml")
        assert 'w:val="24"' in styles_xml, "Normal style size should be repaired to 24 half-points"
        assert b"paper_formatted.docx" not in paper.read_bytes()

        print("SMOKE PASS")
        print(f"requirements={len(requirements['requirements'])} audit={len(audit_rows)} changes={len(changes)}")
        return 0
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
