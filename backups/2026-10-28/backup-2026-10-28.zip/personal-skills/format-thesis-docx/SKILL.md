---
name: format-thesis-docx
description: Complete thesis/dissertation DOCX formatting workflow for extracting every detectable formatting requirement from a template, auditing a user's paper against the template, creating a corrected copy without modifying the original, and reporting all passed, failed, changed, and unresolved requirements. Use when Codex is asked to format, check, compare, or revise a thesis, dissertation, academic paper, graduation paper, or journal manuscript according to a DOCX template, including requirements hidden in comments, styles, headers, footers, page setup, sections, captions, tables, footnotes, references, appendices, and other document parts.
---

# Format Thesis DOCX

Use this skill when a user wants a `.docx` thesis or paper formatted according to a template. The workflow is strict: extract requirements first, audit second, edit only a copy third. Never directly modify the user's original paper.

## Required Workflow

1. Identify the template `.docx` and the user's paper `.docx`. If either is missing or is `.doc`, `.pdf`, or a WPS-only format, ask the user to provide or convert it to `.docx`.
2. Read `references/docx-format-checklist.md` before extraction. Treat it as a minimum anti-omission checklist, not as the complete set of requirements.
3. Run `scripts/extract_requirements.py` on the template. Review both `requirements.json` and `requirements.md`.
4. Add any explicit formatting requirements visible in template text, comments, examples, labels, or instructions that the script cannot infer. Do not skip requirements because they appear informal or are embedded in comments.
5. Run `scripts/audit_format.py` against the user paper and the extracted requirements. Produce a detailed table containing both compliant and non-compliant items.
6. Run `scripts/apply_format.py` to create a formatted copy. The output must be a new file such as `paper_formatted.docx`; the source paper must remain unchanged.
7. Deliver the formatted copy path, the audit report path, the change report path, and a concise list of unresolved manual items.

## Completeness Rules

- Extract every detectable requirement from the template, not only body text, styles, comments, headers, or footers.
- Inspect all accessible DOCX parts: main document, styles, numbering, comments, footnotes, endnotes, headers, footers, settings, section properties, tables, drawings, text boxes, fields, hyperlinks, captions, references, cover-like pages, abstract, keywords, acknowledgements, appendices, and bibliography-like sections.
- Preserve evidence for each requirement: source part, paragraph/table/style/comment identifier when available, and a short text snippet or OOXML-derived location.
- Record requirements that cannot be automatically verified or repaired as manual items. Never silently drop them.
- Keep separate output tables for extracted requirements, audit results, automatic changes, skipped/unresolved items, and assumptions.

## Script Usage

Run scripts from the skill folder or pass absolute paths.

```powershell
python scripts/extract_requirements.py --template "template.docx" --out "work/requirements"
python scripts/audit_format.py --requirements "work/requirements/requirements.json" --paper "paper.docx" --out "work/audit"
python scripts/apply_format.py --requirements "work/requirements/requirements.json" --audit "work/audit/format_audit.csv" --paper "paper.docx" --out "work/fixed"
```

Expected outputs:

- `requirements.json` and `requirements.md`: full extracted template requirements with evidence.
- `format_audit.csv` and `format_audit.md`: every checked item, including pass and fail rows.
- `paper_formatted.docx`: copied and automatically formatted paper.
- `changes.csv` and `changes.md`: exact before/after changes, skipped items, and unresolved tasks.

## Editing Policy

- Always copy the source paper before making any formatting changes.
- Prefer applying style-level and paragraph/run-level formatting that is directly evidenced by the template.
- Do not rewrite academic content, translate text, change citations, renumber figures manually, or alter meaning unless the user explicitly asks.
- If an automatic repair could damage content, leave it unchanged and record it in `changes.md` as a manual task.

## Final Response Checklist

Report:

- Formatted copy path.
- Requirements extraction report path.
- Audit table path.
- Change table path.
- What was automatically fixed.
- What remains manual and why.
- Confirmation that the original paper was not modified.
