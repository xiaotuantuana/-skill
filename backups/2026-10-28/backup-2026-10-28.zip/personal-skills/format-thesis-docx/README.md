# format-thesis-docx

Automated thesis and dissertation DOCX formatting: extract every detectable formatting requirement from a school template, audit a paper against those rules, and create a corrected `.docx` copy without touching the original file.

[中文说明](README.zh-CN.md) · [Live demo](https://wksudud.github.io/format-thesis-docx/) · [Roadmap](ROADMAP.md)

![Demo](docs/screenshots/demo-home.png)

## What This Solves

Thesis formatting standards are often buried in templates, comments, styles, headers, footers, tables, and reference lists. This project turns that hidden standard into an auditable checklist and a reproducible repair pipeline.

- **Extract**: reads `word/document.xml`, `styles.xml`, headers, footers, comments, numbering, and section settings.
- **Audit**: compares the paper against every extracted requirement and records pass, fail, and manual-review rows.
- **Apply**: writes a new `<paper_stem>_formatted.docx`, leaving the original paper untouched.
- **Report**: produces Markdown and CSV reports for requirements, audit results, and changes.

The scripts use only the Python 3 standard library. No `pip install` is required.

## Try It

- **Online demo**: [https://wksudud.github.io/format-thesis-docx/](https://wksudud.github.io/format-thesis-docx/)
- **Sample files**: `examples/template.docx` and `examples/paper_before.docx`
- **Smoke test**: run the complete pipeline in seconds.

```bash
git clone https://github.com/wksudud/format-thesis-docx.git
cd format-thesis-docx
python scripts/make_sample_docx.py
python tests/smoke_test.py
```

Expected output:

```text
SMOKE PASS
requirements=... audit=... changes=...
```

## Quick Start With Your Own Files

```bash
python scripts/extract_requirements.py --template "template.docx" --out "work/requirements"
python scripts/audit_format.py --requirements "work/requirements/requirements.json" --paper "paper.docx" --out "work/audit"
python scripts/apply_format.py --requirements "work/requirements/requirements.json" --audit "work/audit/format_audit.csv" --paper "paper.docx" --out "work/fixed"
```

Outputs:

| File | Description |
| --- | --- |
| `requirements.json` / `requirements.md` | Extracted template requirements with source evidence |
| `format_audit.csv` / `format_audit.md` | Per-item audit table |
| `<paper_stem>_formatted.docx` | New corrected copy; original is never modified |
| `changes.csv` / `changes.md` | Applied fixes, skipped items, and manual tasks |

## Directory Structure

```text
format-thesis-docx/
  README.md                 # English documentation
  README.zh-CN.md           # Chinese documentation
  ROADMAP.md                # Product and repository roadmap
  SKILL.md                  # Agent skill definition
  scripts/
    extract_requirements.py # Extract requirements from a template DOCX
    audit_format.py         # Audit a paper against requirements
    apply_format.py         # Create a corrected DOCX copy
    make_sample_docx.py     # Generate synthetic demo files
    build_demo.py           # Rebuild the static GitHub Pages demo data
  tests/
    smoke_test.py           # End-to-end pipeline smoke test
  examples/
    template.docx           # Synthetic school-style template
    paper_before.docx       # Synthetic paper with formatting issues
  docs/
    index.html              # Static live demo
    data/demo.json          # Generated sample report data
    samples/                # Downloadable demo files
    screenshots/            # Screenshots used in README and demo
  references/
    docx-format-checklist.md # 200+ anti-omission checklist
```

## Roadmap

- Add a web upload workflow for template + paper.
- Add more repair rules for table width, captions, numbering, and page breaks.
- Add a visual before/after diff view.
- Add CI checks that run the smoke test on every push.
- Add English/Chinese sample templates for common university formats.

See [ROADMAP.md](ROADMAP.md) for details.

## Limitations

- Supports `.docx` only; convert `.doc`, `.pdf`, or WPS-only files first.
- Handles formatting, not academic content, citations, or figure renumbering.
- Ambiguous rules are reported as manual tasks instead of risking content changes.
- Review `changes.md` before accepting the formatted copy.

## Privacy

All processing is local. The scripts do not upload your paper, template, reports, or personal data.

## License

[MIT](LICENSE)
