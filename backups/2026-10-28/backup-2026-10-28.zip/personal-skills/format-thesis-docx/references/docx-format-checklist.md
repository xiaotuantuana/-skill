# DOCX Thesis Format Anti-Omission Checklist

Use this checklist as the minimum set of areas to inspect. Template-specific requirements found elsewhere always take precedence and must be added even if they are not listed here.

## Document-Wide

- File format, compatibility settings, language, proofing settings, document defaults.
- Page size, orientation, margins, gutter, mirror margins, columns, line numbering, page borders.
- Section breaks and section-specific page setup.
- Header and footer content, distance from edge, odd/even/first-page variants.
- Page numbering format, start value, placement, restart rules.

## Styles and Text

- Style definitions, based-on style, next style, linked styles, aliases.
- Chinese font, Western font, East Asian font, complex script font.
- Font size, bold, italic, underline, color, highlight, all caps, small caps.
- Superscript/subscript, character spacing, scaling, position.
- Paragraph alignment, line spacing, before/after spacing, indentation, hanging indent.
- Widow/orphan control, keep with next, keep lines together, page break before.
- Borders, shading, tabs, leader dots.

## Structure

- Cover, title page, originality statement, authorization statement.
- Chinese abstract, English abstract, keywords.
- Table of contents, list of figures, list of tables, generated fields.
- Heading levels 1-N, numbering, multilevel list mapping, outline levels.
- Body text, block quotations, examples, notes.
- Acknowledgements, references/bibliography, appendices.

## Objects

- Tables: style, width, alignment, borders, shading, row height, cell margins, header rows, caption placement.
- Figures/drawings/images: placement, wrapping, size, alignment, caption format.
- Captions for figures, tables, formulas, algorithms, and other objects.
- Cross-references, hyperlinks, bookmarks, fields, equation numbering.
- Equations and formulas: alignment, numbering, font, spacing.
- Footnotes/endnotes: numbering, separators, text style, spacing.
- Text boxes, shapes, SmartArt, charts, embedded objects.

## Explicit Instructions

- Comments, replies, tracked formatting notes, hidden text, placeholder text, and template hints.
- Any paragraph that contains requirement language such as "font", "size", "spacing", "margin", "page", "标题", "字体", "字号", "行距", "缩进", "页眉", "页脚", "页码", "格式", "要求", "示例", "不得", "应", "须", or "按".
- Requirements implied by named example paragraphs, style names, captions, section labels, or surrounding template text.

## Reporting

- Every item must be reported as pass, fail, not applicable, auto-fixed, skipped, or manual.
- If a requirement cannot be verified from OOXML, list it as manual with the source evidence.
- If a requirement cannot be safely repaired, list it as unresolved with a reason.
