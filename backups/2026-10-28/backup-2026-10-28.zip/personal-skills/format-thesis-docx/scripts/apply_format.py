#!/usr/bin/env python3
"""Copy a DOCX paper and apply safe formatting fixes from extracted requirements."""

from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
import tempfile
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
ET.register_namespace("w", NS["w"])


def qn(tag: str) -> str:
    prefix, name = tag.split(":", 1)
    return f"{{{NS[prefix]}}}{name}"


def ensure(parent: ET.Element, tag: str) -> ET.Element:
    found = parent.find(tag, NS)
    if found is None:
        found = ET.SubElement(parent, qn(tag))
    return found


def get_attr(el: ET.Element | None, name: str) -> str:
    return "" if el is None else (el.get(qn(name)) or "")


def set_attr(el: ET.Element, name: str, value: str) -> None:
    el.set(qn(name), value)


def set_run_property(rpr: ET.Element, prop: str, value: str) -> tuple[str, str] | None:
    if prop.startswith("font."):
        if prop in {"font.ascii", "font.eastAsia", "font.hAnsi", "font.cs"}:
            fonts = ensure(rpr, "w:rFonts")
            key = "w:" + prop.split(".", 1)[1]
            before = get_attr(fonts, key)
            set_attr(fonts, key, value)
            return before, value
        mapping = {
            "font.size_half_points": ("w:sz", "w:val"),
            "font.sizeCs_half_points": ("w:szCs", "w:val"),
            "font.underline": ("w:u", "w:val"),
            "font.color": ("w:color", "w:val"),
            "font.highlight": ("w:highlight", "w:val"),
            "font.vertAlign": ("w:vertAlign", "w:val"),
        }
        if prop in mapping:
            tag, key = mapping[prop]
            el = ensure(rpr, tag)
            before = get_attr(el, key)
            set_attr(el, key, value)
            return before, value
        if prop in {"font.bold", "font.italic"} and value == "true":
            tag = "w:b" if prop == "font.bold" else "w:i"
            before = "true" if rpr.find(tag, NS) is not None else ""
            ensure(rpr, tag)
            return before, "true"
    return None


def set_para_property(ppr: ET.Element, prop: str, value: str) -> tuple[str, str] | None:
    mapping = {
        "paragraph.style": ("w:pStyle", "w:val"),
        "paragraph.align": ("w:jc", "w:val"),
        "paragraph.spacing.before": ("w:spacing", "w:before"),
        "paragraph.spacing.after": ("w:spacing", "w:after"),
        "paragraph.spacing.line": ("w:spacing", "w:line"),
        "paragraph.spacing.lineRule": ("w:spacing", "w:lineRule"),
        "paragraph.ind.left": ("w:ind", "w:left"),
        "paragraph.ind.right": ("w:ind", "w:right"),
        "paragraph.ind.firstLine": ("w:ind", "w:firstLine"),
        "paragraph.ind.hanging": ("w:ind", "w:hanging"),
    }
    if prop in mapping:
        tag, key = mapping[prop]
        el = ensure(ppr, tag)
        before = get_attr(el, key)
        set_attr(el, key, value)
        return before, value
    if prop in {"paragraph.keepNext", "paragraph.keepLines", "paragraph.pageBreakBefore"} and value == "true":
        tag = "w:" + prop.split(".")[-1]
        before = "true" if ppr.find(tag, NS) is not None else ""
        ensure(ppr, tag)
        return before, "true"
    return None


def set_section_property(sect: ET.Element, prop: str, value: str) -> tuple[str, str] | None:
    mapping = {
        "section.page.width": ("w:pgSz", "w:w"),
        "section.page.height": ("w:pgSz", "w:h"),
        "section.page.orientation": ("w:pgSz", "w:orient"),
        "section.margin.top": ("w:pgMar", "w:top"),
        "section.margin.right": ("w:pgMar", "w:right"),
        "section.margin.bottom": ("w:pgMar", "w:bottom"),
        "section.margin.left": ("w:pgMar", "w:left"),
        "section.margin.header": ("w:pgMar", "w:header"),
        "section.margin.footer": ("w:pgMar", "w:footer"),
        "section.columns": ("w:cols", "w:num"),
    }
    if prop not in mapping:
        return None
    tag, key = mapping[prop]
    el = ensure(sect, tag)
    before = get_attr(el, key)
    set_attr(el, key, value)
    return before, value


def unzip_docx(docx: Path, directory: Path) -> None:
    with zipfile.ZipFile(docx) as zf:
        zf.extractall(directory)


def zip_docx(directory: Path, docx: Path) -> None:
    with zipfile.ZipFile(docx, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in directory.rglob("*"):
            if path.is_file():
                zf.write(path, path.relative_to(directory).as_posix())


def load_audit(path: Path | None) -> dict[str, str]:
    if path is None or not path.exists():
        return {}
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return {row["requirement_id"]: row.get("status", "") for row in csv.DictReader(f)}


def apply(requirements: list[dict], audit_status: dict[str, str], paper: Path, out_dir: Path) -> tuple[Path, list[dict]]:
    out_dir.mkdir(parents=True, exist_ok=True)
    output = out_dir / f"{paper.stem}_formatted{paper.suffix}"
    shutil.copy2(paper, output)
    changes: list[dict] = []
    with tempfile.TemporaryDirectory() as td:
        work = Path(td)
        unzip_docx(output, work)
        styles_path = work / "word" / "styles.xml"
        doc_path = work / "word" / "document.xml"
        styles_root = ET.parse(styles_path) if styles_path.exists() else None
        doc_root = ET.parse(doc_path) if doc_path.exists() else None

        for req in requirements:
            status_from_audit = audit_status.get(req["id"], "") if audit_status else ""
            if status_from_audit == "pass":
                continue
            if status_from_audit in {"manual", "not applicable", "not-applicable"}:
                changes.append(change_row(req, "", "", "skipped", "Manual or non-comparable audit item; review the extracted evidence."))
                continue
            result = None
            location = ""
            if req["category"] == "style" and req["target"].startswith("style:") and styles_root is not None:
                style_id = req["target"].split(":", 1)[1]
                style = styles_root.getroot().find(f".//w:style[@w:styleId='{style_id}']", NS)
                if style is not None:
                    if req["property"].startswith("font."):
                        result = set_run_property(ensure(style, "w:rPr"), req["property"], req["expected"])
                    else:
                        result = set_para_property(ensure(style, "w:pPr"), req["property"], req["expected"])
                    location = req["target"]
            elif req["category"] == "section" and req["target"].startswith("section:") and doc_root is not None:
                idx = int(req["target"].split(":", 1)[1]) - 1
                sections = doc_root.getroot().findall(".//w:sectPr", NS)
                if 0 <= idx < len(sections):
                    result = set_section_property(sections[idx], req["property"], req["expected"])
                    location = req["target"]

            if result is None:
                changes.append(change_row(req, "", "", "skipped", "Not safely auto-applicable; manual review required."))
            else:
                before, after = result
                status = "changed" if before != after else "already-set"
                changes.append(change_row(req, before, after, status, location))

        if styles_root is not None:
            styles_root.write(styles_path, encoding="utf-8", xml_declaration=True)
        if doc_root is not None:
            doc_root.write(doc_path, encoding="utf-8", xml_declaration=True)
        zip_docx(work, output)
    return output, changes


def change_row(req: dict, before: str, after: str, status: str, note: str) -> dict:
    return {
        "requirement_id": req["id"],
        "category": req["category"],
        "target": req["target"],
        "property": req["property"],
        "before": before,
        "after": after,
        "status": status,
        "note": note,
        "evidence": req.get("evidence", ""),
    }


def write_csv(rows: list[dict], path: Path) -> None:
    fields = ["requirement_id", "category", "target", "property", "before", "after", "status", "note", "evidence"]
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(rows: list[dict], output_docx: Path, path: Path) -> None:
    lines = [
        "# Thesis Formatting Changes",
        "",
        f"Formatted copy: `{output_docx}`",
        "",
        "| ID | Category | Target | Property | Before | After | Status | Note |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for row in rows:
        vals = [row["requirement_id"], row["category"], row["target"], row["property"], row["before"], row["after"], row["status"], row["note"]]
        safe = [re.sub(r"\s+", " ", str(v)).replace("|", "\\|") for v in vals]
        lines.append("| " + " | ".join(safe) + " |")
    unresolved = [r for r in rows if r["status"] == "skipped"]
    lines += ["", "## Unresolved Manual Items", ""]
    if unresolved:
        for row in unresolved:
            lines.append(f"- {row['requirement_id']} {row['target']} {row['property']}: {row['note']}")
    else:
        lines.append("- None.")
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--requirements", required=True, type=Path)
    parser.add_argument("--audit", type=Path)
    parser.add_argument("--paper", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    data = json.loads(args.requirements.read_text(encoding="utf-8"))
    output_docx, rows = apply(data["requirements"], load_audit(args.audit), args.paper, args.out)
    write_csv(rows, args.out / "changes.csv")
    write_markdown(rows, output_docx, args.out / "changes.md")
    print(f"Created formatted copy: {output_docx}")
    print(f"Wrote change report to {args.out}")


if __name__ == "__main__":
    main()
