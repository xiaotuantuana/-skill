#!/usr/bin/env python3
"""Audit a DOCX paper against extracted template requirements."""

from __future__ import annotations

import argparse
import csv
import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}


def qn(tag: str) -> str:
    prefix, name = tag.split(":", 1)
    return f"{{{NS[prefix]}}}{name}"


def attr(el: ET.Element | None, name: str) -> str | None:
    return None if el is None else el.get(qn(name))


def load_xml(zf: zipfile.ZipFile, name: str) -> ET.Element | None:
    try:
        return ET.fromstring(zf.read(name))
    except KeyError:
        return None


def run_props(rpr: ET.Element | None) -> dict[str, str]:
    if rpr is None:
        return {}
    fonts = rpr.find("w:rFonts", NS)
    props = {
        "font.ascii": attr(fonts, "w:ascii"),
        "font.eastAsia": attr(fonts, "w:eastAsia"),
        "font.hAnsi": attr(fonts, "w:hAnsi"),
        "font.cs": attr(fonts, "w:cs"),
        "font.size_half_points": attr(rpr.find("w:sz", NS), "w:val"),
        "font.sizeCs_half_points": attr(rpr.find("w:szCs", NS), "w:val"),
        "font.bold": "true" if rpr.find("w:b", NS) is not None else None,
        "font.italic": "true" if rpr.find("w:i", NS) is not None else None,
        "font.underline": attr(rpr.find("w:u", NS), "w:val"),
        "font.color": attr(rpr.find("w:color", NS), "w:val"),
        "font.highlight": attr(rpr.find("w:highlight", NS), "w:val"),
        "font.vertAlign": attr(rpr.find("w:vertAlign", NS), "w:val"),
    }
    return {k: v for k, v in props.items() if v not in (None, "")}


def para_props(ppr: ET.Element | None) -> dict[str, str]:
    if ppr is None:
        return {}
    spacing = ppr.find("w:spacing", NS)
    ind = ppr.find("w:ind", NS)
    num = ppr.find("w:numPr", NS)
    props = {
        "paragraph.style": attr(ppr.find("w:pStyle", NS), "w:val"),
        "paragraph.align": attr(ppr.find("w:jc", NS), "w:val"),
        "paragraph.spacing.before": attr(spacing, "w:before"),
        "paragraph.spacing.after": attr(spacing, "w:after"),
        "paragraph.spacing.line": attr(spacing, "w:line"),
        "paragraph.spacing.lineRule": attr(spacing, "w:lineRule"),
        "paragraph.ind.left": attr(ind, "w:left"),
        "paragraph.ind.right": attr(ind, "w:right"),
        "paragraph.ind.firstLine": attr(ind, "w:firstLine"),
        "paragraph.ind.hanging": attr(ind, "w:hanging"),
        "paragraph.keepNext": "true" if ppr.find("w:keepNext", NS) is not None else None,
        "paragraph.keepLines": "true" if ppr.find("w:keepLines", NS) is not None else None,
        "paragraph.pageBreakBefore": "true" if ppr.find("w:pageBreakBefore", NS) is not None else None,
        "numbering.level": attr(num.find("w:ilvl", NS), "w:val") if num is not None else None,
        "numbering.id": attr(num.find("w:numId", NS), "w:val") if num is not None else None,
    }
    return {k: v for k, v in props.items() if v not in (None, "")}


def section_props(sect: ET.Element | None) -> dict[str, str]:
    if sect is None:
        return {}
    size = sect.find("w:pgSz", NS)
    mar = sect.find("w:pgMar", NS)
    cols = sect.find("w:cols", NS)
    props = {
        "section.page.width": attr(size, "w:w"),
        "section.page.height": attr(size, "w:h"),
        "section.page.orientation": attr(size, "w:orient") or "portrait",
        "section.margin.top": attr(mar, "w:top"),
        "section.margin.right": attr(mar, "w:right"),
        "section.margin.bottom": attr(mar, "w:bottom"),
        "section.margin.left": attr(mar, "w:left"),
        "section.margin.header": attr(mar, "w:header"),
        "section.margin.footer": attr(mar, "w:footer"),
        "section.columns": attr(cols, "w:num"),
    }
    return {k: v for k, v in props.items() if v not in (None, "")}


def collect_doc_facts(docx: Path) -> dict[str, dict[str, str]]:
    facts: dict[str, dict[str, str]] = {"document": {}}
    with zipfile.ZipFile(docx) as zf:
        styles = load_xml(zf, "word/styles.xml")
        if styles is not None:
            for style in styles.findall(".//w:style", NS):
                style_id = attr(style, "w:styleId") or "unknown"
                facts[f"style:{style_id}"] = {**para_props(style.find("w:pPr", NS)), **run_props(style.find("w:rPr", NS))}
        doc = load_xml(zf, "word/document.xml")
        if doc is not None:
            for idx, sect in enumerate(doc.findall(".//w:sectPr", NS), start=1):
                facts[f"section:{idx}"] = section_props(sect)
    return facts


def audit(requirements: list[dict], paper: Path) -> list[dict]:
    facts = collect_doc_facts(paper)
    rows: list[dict] = []
    for req in requirements:
        actual = ""
        status = "manual"
        note = "Manual review required; requirement is explicit, example-based, or not safely machine-comparable."
        target = req["target"]
        prop = req["property"]
        if target in facts and prop in facts[target]:
            actual = facts[target][prop]
            status = "pass" if actual == req["expected"] else "fail"
            note = "Compared exact OOXML property value."
        elif req.get("category") in {"style", "section"}:
            actual = ""
            status = "fail"
            note = "Comparable target/property missing in paper."
        rows.append(
            {
                "requirement_id": req["id"],
                "category": req["category"],
                "target": target,
                "property": prop,
                "expected": req["expected"],
                "actual": actual,
                "status": status,
                "source_part": req["source_part"],
                "evidence": req["evidence"],
                "note": note,
            }
        )
    return rows


def write_csv(rows: list[dict], path: Path) -> None:
    fields = ["requirement_id", "category", "target", "property", "expected", "actual", "status", "source_part", "evidence", "note"]
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_markdown(rows: list[dict], path: Path) -> None:
    lines = [
        "# Thesis Format Audit",
        "",
        "| ID | Category | Target | Property | Expected | Actual | Status | Evidence | Note |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for row in rows:
        vals = [row["requirement_id"], row["category"], row["target"], row["property"], row["expected"], row["actual"], row["status"], row["evidence"], row["note"]]
        safe = [re.sub(r"\s+", " ", str(v)).replace("|", "\\|") for v in vals]
        lines.append("| " + " | ".join(safe) + " |")
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--requirements", required=True, type=Path)
    parser.add_argument("--paper", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    data = json.loads(args.requirements.read_text(encoding="utf-8"))
    rows = audit(data["requirements"], args.paper)
    write_csv(rows, args.out / "format_audit.csv")
    write_markdown(rows, args.out / "format_audit.md")
    print(f"Audited {len(rows)} requirements to {args.out}")


if __name__ == "__main__":
    main()
