#!/usr/bin/env python3
"""Build the static GitHub Pages demo from a real smoke run of the pipeline."""

from __future__ import annotations

import csv
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
EXAMPLES = ROOT / "examples"
DOCS = ROOT / "docs"
DATA_DIR = DOCS / "data"
SAMPLES_DIR = DOCS / "samples"
SCREENSHOT_DIR = DOCS / "screenshots"


def run_python(script: Path, *args: str) -> None:
    subprocess.run(
        [sys.executable, str(script), *args],
        cwd=str(ROOT),
        check=True,
        capture_output=True,
        text=True,
    )


def build() -> None:
    DOCS.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    SAMPLES_DIR.mkdir(parents=True, exist_ok=True)
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)

    work = Path(tempfile.mkdtemp(prefix="format-thesis-demo-"))
    try:
        req_dir = work / "requirements"
        audit_dir = work / "audit"
        fix_dir = work / "fixed"
        run_python(SCRIPTS / "extract_requirements.py", "--template", str(EXAMPLES / "template.docx"), "--out", str(req_dir))
        run_python(
            SCRIPTS / "audit_format.py",
            "--requirements",
            str(req_dir / "requirements.json"),
            "--paper",
            str(EXAMPLES / "paper_before.docx"),
            "--out",
            str(audit_dir),
        )
        run_python(
            SCRIPTS / "apply_format.py",
            "--requirements",
            str(req_dir / "requirements.json"),
            "--audit",
            str(audit_dir / "format_audit.csv"),
            "--paper",
            str(EXAMPLES / "paper_before.docx"),
            "--out",
            str(fix_dir),
        )

        paper_stem = (EXAMPLES / "paper_before.docx").stem
        requirements = json.loads((req_dir / "requirements.json").read_text(encoding="utf-8"))
        audit = list(csv.DictReader((audit_dir / "format_audit.csv").open(encoding="utf-8-sig")))
        changes = list(csv.DictReader((fix_dir / "changes.csv").open(encoding="utf-8-sig")))
        data = {
            "generated_at": "static demo data",
            "summary": {
                "requirements": len(requirements["requirements"]),
                "audit": len(audit),
                "failures": sum(1 for row in audit if row["status"] == "fail"),
                "changes": len(changes),
                "applied": sum(1 for row in changes if row["status"] == "changed"),
            },
            "requirements": requirements["requirements"][:12],
            "audit": audit[:12],
            "changes": changes[:12],
        }
        (DATA_DIR / "demo.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

        shutil.copy2(EXAMPLES / "template.docx", SAMPLES_DIR / "template.docx")
        shutil.copy2(EXAMPLES / "paper_before.docx", SAMPLES_DIR / "paper_before.docx")
        shutil.copy2(fix_dir / f"{paper_stem}_formatted.docx", SAMPLES_DIR / "paper_formatted.docx")
        shutil.copy2(audit_dir / "format_audit.csv", SAMPLES_DIR / "format_audit.csv")
        shutil.copy2(fix_dir / "changes.csv", SAMPLES_DIR / "changes.csv")

        print("DEMO BUILD PASS")
        print(f"docs={DOCS}")
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    build()
