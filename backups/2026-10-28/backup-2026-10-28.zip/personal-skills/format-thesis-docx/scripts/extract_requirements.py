#!/usr/bin/env python3
"""Extract detectable thesis-format requirements from a DOCX template."""

from __future__ import annotations

import argparse
import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
}

FORMAT_WORDS = re.compile(
    r"(font|size|spacing|margin|header|footer|page|caption|reference|"
    r"标题|字体|字号|行距|缩进|页眉|页脚|页码|格式|要求|示例|不得|应|须|按|"
    r"目录|图|表|公式|参考文献|摘要|关键词|附录)"
)


def qn(tag: str) -> str:
    prefix, name = tag.split(":", 1)
    return f"{{{NS[prefix]}}}{name}"


def attr(el: ET.Element | None, name: str) -> str | None:
    return None if el is None else el.get(qn(name))


def text_of(el: ET.Element | None) -> str:
    if el is None:
        return ""
    return "".join(t.text or "" for t in el.findall(".//w:t", NS)).strip()


def load_xml(zf: zipfile.ZipFile, name: str) -> ET.Element | None:
    try:
        return ET.fromstring(zf.read(name))
    except KeyError:
        return None


def read_parts(zf: zipfile.ZipFile) -> dict[str, ET.Element]:
    wanted = [
        "word/document.xml",
        "word/styles.xml",
        "word/numbering.xml",
        "word/comments.xml",
        "word/footnotes.xml",
        "word/endnotes.xml",
        "word/settings.xml",
    ]
    wanted += [n for n in zf.namelist() if re.match(r"word/(header|footer)\d+\.xml$", n)]
    return {name: root for name in wanted if (root := load_xml(zf, name)) is not None}


def run_props(rpr: ET.Element | None) -> dict[str, str]:
    if rpr is None:
        return {}
    fonts = rpr.find("w:rFonts", NS)
    props = {
        "font.ascii": attr(fonts, "w:ascii"),
        "font.eastAsia": attr(fonts, "w:eastAsia"),
        "font.hAnsi": attr(fonts, "w:hAnsi"),
        "font.cs": attr(fonts, "w:cs"),
        "font.size_half_points": attr(rpr.find("w:sz", NS), "w:val"),
        "font.sizeCs_half_points": attr(rpr.find("w:szCs", NS), "w:val"),
        "font.bold": "true" if rpr.find("w:b", NS) is not None else None,
        "font.italic": "true" if rpr.find("w:i", NS) is not None else None,
        "font.underline": attr(rpr.find("w:u", NS), "w:val"),
        "font.color": attr(rpr.find("w:color", NS), "w:val"),
        "font.highlight": attr(rpr.find("w:highlight", NS), "w:val"),
        "font.vertAlign": attr(rpr.find("w:vertAlign", NS), "w:val"),
    }
    return {k: v for k, v in props.items() if v not in (None, "")}


def para_props(ppr: ET.Element | None) -> dict[str, str]:
    if ppr is None:
        return {}
    spacing = ppr.find("w:spacing", NS)
    ind = ppr.find("w:ind", NS)
    num = ppr.find("w:numPr", NS)
    props = {
        "paragraph.style": attr(ppr.find("w:pStyle", NS), "w:val"),
        "paragraph.align": attr(ppr.find("w:jc", NS), "w:val"),
        "paragraph.spacing.before": attr(spacing, "w:before"),
        "paragraph.spacing.after": attr(spacing, "w:after"),
        "paragraph.spacing.line": attr(spacing, "w:line"),
        "paragraph.spacing.lineRule": attr(spacing, "w:lineRule"),
        "paragraph.ind.left": attr(ind, "w:left"),
        "paragraph.ind.right": attr(ind, "w:right"),
        "paragraph.ind.firstLine": attr(ind, "w:firstLine"),
        "paragraph.ind.hanging": attr(ind, "w:hanging"),
        "paragraph.keepNext": "true" if ppr.find("w:keepNext", NS) is not None else None,
        "paragraph.keepLines": "true" if ppr.find("w:keepLines", NS) is not None else None,
        "paragraph.pageBreakBefore": "true" if ppr.find("w:pageBreakBefore", NS) is not None else None,
        "numbering.level": attr(num.find("w:ilvl", NS), "w:val") if num is not None else None,
        "numbering.id": attr(num.find("w:numId", NS), "w:val") if num is not None else None,
    }
    return {k: v for k, v in props.items() if v not in (None, "")}


def section_props(sect: ET.Element | None) -> dict[str, str]:
    if sect is None:
        return {}
    size = sect.find("w:pgSz", NS)
    mar = sect.find("w:pgMar", NS)
    cols = sect.find("w:cols", NS)
    props = {
        "section.page.width": attr(size, "w:w"),
        "section.page.height": attr(size, "w:h"),
        "section.page.orientation": attr(size, "w:orient") or "portrait",
        "section.margin.top": attr(mar, "w:top"),
        "section.margin.right": attr(mar, "w:right"),
        "section.margin.bottom": attr(mar, "w:bottom"),
        "section.margin.left": attr(mar, "w:left"),
        "section.margin.header": attr(mar, "w:header"),
        "section.margin.footer": attr(mar, "w:footer"),
        "section.columns": attr(cols, "w:num"),
    }
    return {k: v for k, v in props.items() if v not in (None, "")}


def add_item(items: list[dict], category: str, target: str, prop: str, expected: str, source: str, evidence: str, auto: bool = True) -> None:
    items.append(
        {
            "id": f"R{len(items) + 1:04d}",
            "category": category,
            "target": target,
            "property": prop,
            "expected": str(expected),
            "source_part": source,
            "evidence": evidence[:300],
            "auto_applicable": auto,
        }
    )


def extract(template: Path) -> list[dict]:
    items: list[dict] = []
    with zipfile.ZipFile(template) as zf:
        parts = read_parts(zf)

        styles = parts.get("word/styles.xml")
        if styles is not None:
            for style in styles.findall(".//w:style", NS):
                style_id = attr(style, "w:styleId") or "unknown"
                style_type = attr(style, "w:type") or "unknown"
                name = attr(style.find("w:name", NS), "w:val") or style_id
                target = f"style:{style_id}"
                evidence = f"{style_type} style {name} ({style_id})"
                for key, value in {**para_props(style.find("w:pPr", NS)), **run_props(style.find("w:rPr", NS))}.items():
                    add_item(items, "style", target, key, value, "word/styles.xml", evidence)

        for part_name, root in parts.items():
            if part_name == "word/styles.xml":
                continue
            for idx, para in enumerate(root.findall(".//w:p", NS), start=1):
                txt = text_of(para)
                props = {**para_props(para.find("w:pPr", NS)), **run_props(para.find("w:r/w:rPr", NS))}
                if props:
                    target = f"paragraph-example:{part_name}:{idx}"
                    evidence = txt or f"paragraph {idx}"
                    for key, value in props.items():
                        add_item(items, "paragraph-example", target, key, value, part_name, evidence, auto=False)
                if txt and FORMAT_WORDS.search(txt):
                    add_item(items, "explicit-instruction", f"text:{part_name}:{idx}", "instruction.text", txt, part_name, txt, auto=False)

            for idx, table in enumerate(root.findall(".//w:tbl", NS), start=1):
                tbl_pr = table.find("w:tblPr", NS)
                if tbl_pr is not None:
                    target = f"table-example:{part_name}:{idx}"
                    style = attr(tbl_pr.find("w:tblStyle", NS), "w:val")
                    width = attr(tbl_pr.find("w:tblW", NS), "w:w")
                    if style:
                        add_item(items, "table", target, "table.style", style, part_name, f"table {idx}", auto=False)
                    if width:
                        add_item(items, "table", target, "table.width", width, part_name, f"table {idx}", auto=False)

            for idx, sect in enumerate(root.findall(".//w:sectPr", NS), start=1):
                for key, value in section_props(sect).items():
                    add_item(items, "section", f"section:{idx}", key, value, part_name, f"section {idx}")

        numbering = parts.get("word/numbering.xml")
        if numbering is not None:
            for idx, lvl in enumerate(numbering.findall(".//w:lvl", NS), start=1):
                fmt = attr(lvl.find("w:numFmt", NS), "w:val")
                text = attr(lvl.find("w:lvlText", NS), "w:val")
                if fmt:
                    add_item(items, "numbering", f"numbering-level:{idx}", "numbering.format", fmt, "word/numbering.xml", text or f"level {idx}", auto=False)
                if text:
                    add_item(items, "numbering", f"numbering-level:{idx}", "numbering.text", text, "word/numbering.xml", text, auto=False)

    return items


def write_markdown(items: list[dict], path: Path) -> None:
    lines = [
        "# Extracted Thesis Template Requirements",
        "",
        "Every detectable requirement found in the template is listed below. Manual rows must be reviewed and completed by the agent.",
        "",
        "| ID | Category | Target | Property | Expected | Source | Evidence | Auto |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for item in items:
        vals = [item["id"], item["category"], item["target"], item["property"], item["expected"], item["source_part"], item["evidence"], str(item["auto_applicable"])]
        safe = [str(v).replace("|", "\\|").replace("\n", " ") for v in vals]
        lines.append("| " + " | ".join(safe) + " |")
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--template", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    items = extract(args.template)
    (args.out / "requirements.json").write_text(json.dumps({"template": str(args.template), "requirements": items}, ensure_ascii=False, indent=2), encoding="utf-8")
    write_markdown(items, args.out / "requirements.md")
    print(f"Extracted {len(items)} requirements to {args.out}")


if __name__ == "__main__":
    main()
