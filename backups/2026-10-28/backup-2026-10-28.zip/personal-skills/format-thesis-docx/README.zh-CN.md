# format-thesis-docx

论文/学位论文 DOCX 自动格式整理：从学校格式模板中提取可检测的格式要求，逐项审计论文，并生成一份只修正格式的新 `.docx` 副本，原文件不会被修改。

[English](README.md) · [在线体验](https://wksudud.github.io/format-thesis-docx/) · [Roadmap](ROADMAP.md)

![Demo](docs/screenshots/demo-home.png)

## 解决的问题

论文格式要求常常散落在模板、样式、页眉页脚、批注、目录、表格、参考文献等位置。本项目把这些隐藏要求变成可审计的清单，并形成可复现的自动修复流程。

- **提取**：读取 `document.xml`、`styles.xml`、页眉页脚、批注、编号和分节设置。
- **审计**：逐项比较论文与提取出的要求，记录通过、失败和需要人工判断的项目。
- **修复**：生成新的 `<paper_stem>_formatted.docx`，不改动原论文。
- **报告**：输出 Markdown/CSV 的要求、审计和修改记录。

脚本仅使用 Python 3 标准库，无需 `pip install`。

## 快速体验

- **在线 Demo**：[https://wksudud.github.io/format-thesis-docx/](https://wksudud.github.io/format-thesis-docx/)
- **示例文件**：`examples/template.docx`、`examples/paper_before.docx`
- **Smoke Test**：几秒钟跑完整流程。

```bash
git clone https://github.com/wksudud/format-thesis-docx.git
cd format-thesis-docx
python scripts/make_sample_docx.py
python tests/smoke_test.py
```

预期输出：

```text
SMOKE PASS
requirements=... audit=... changes=...
```

## 用自己的文件

```bash
python scripts/extract_requirements.py --template "template.docx" --out "work/requirements"
python scripts/audit_format.py --requirements "work/requirements/requirements.json" --paper "paper.docx" --out "work/audit"
python scripts/apply_format.py --requirements "work/requirements/requirements.json" --audit "work/audit/format_audit.csv" --paper "paper.docx" --out "work/fixed"
```

输出文件：

| 文件 | 说明 |
| --- | --- |
| `requirements.json` / `requirements.md` | 从模板提取的格式要求及来源证据 |
| `format_audit.csv` / `format_audit.md` | 逐项审计结果 |
| `<paper_stem>_formatted.docx` | 新的修正副本，原文件不改动 |
| `changes.csv` / `changes.md` | 自动修改、跳过项和人工任务 |

## 目录结构

```text
format-thesis-docx/
  README.md                 # 英文文档
  README.zh-CN.md           # 中文文档
  ROADMAP.md                # 产品与仓库 Roadmap
  SKILL.md                  # Agent Skill 定义
  scripts/
    extract_requirements.py # 从模板提取格式要求
    audit_format.py         # 审计论文格式
    apply_format.py         # 生成修正后的 DOCX
    make_sample_docx.py     # 生成演示样例
    build_demo.py           # 重建静态 Demo 数据
  tests/
    smoke_test.py           # 端到端 Smoke Test
  examples/
    template.docx           # 模拟学校模板
    paper_before.docx       # 存在格式问题的模拟论文
  docs/
    index.html              # 在线体验页
    data/demo.json          # 生成的示例报告数据
    samples/                # 可下载示例文件
    screenshots/            # 截图
  references/
    docx-format-checklist.md # 200+ 防遗漏检查项
```

## Roadmap

- 增加网页上传模板和论文的工作流。
- 增加表格宽度、题注、编号、分页等更多自动修复规则。
- 增加修改前后可视对比。
- 增加每次推送自动运行 Smoke Test 的 CI。
- 增加常见高校格式的中英文示例模板。

详见 [ROADMAP.md](ROADMAP.md)。

## 边界说明

- 仅支持 `.docx`；`.doc`、`.pdf`、WPS 专有格式需先转换。
- 只处理格式，不改内容、引用或图表编号。
- 有歧义的项目会标为人工任务，避免自动改动破坏内容。
- 接受修正副本前，请先阅读 `changes.md`。

## 隐私

所有处理都在本地完成，脚本不会上传论文、模板、报告或个人数据。

## License

[MIT](LICENSE)
